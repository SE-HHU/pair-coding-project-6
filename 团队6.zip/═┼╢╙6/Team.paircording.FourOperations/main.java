package Team.paircording.FourOperations;

import java.io.*;
import java.util.*;

public class main {

    public static void main(String[] args) {
        Create ex =new Create();                       //实例化生成类
        InfixToSuffix its=new InfixToSuffix();         //实例化表达式计算类
        FileHanding fo=new FileHanding();              //实例化文件处理类

        File file1 = new File("Exercises.txt");
        File file2 = new File("Answers.txt");
        File file3 = new File("MyAnswers.txt");
        File file4 = new File("Grade.txt");

        int n=1;                                       //参数默认值（n:题目个数  ）
        int m=10;                                      //参数默认值（m:参数范围  ）
        int a=0;                                       //参数默认值（a:参数控制是否带括号 ）

        System.out.println("---------------四则运算程序---------------");
        System.out.println("-n：生成题目个数");
        System.out.println("-r：参数数值范围");
        System.out.println("-b：参数控制括号");
        System.out.println("-g：查看测试结果");
        System.out.println("Do：执行程序");
        System.out.println("请输入指令：");

        Scanner in =new Scanner(System.in);
        while(in.hasNext())
        {
            switch(in.next())
            {
                case "-n" :
                    System.out.println("请输入要生成的题目个数：");
                    n=in.nextInt();
                    break;
                case "-r":
                    System.out.println("请输入运算数的数值范围：");
                    m=in.nextInt();
                    break;
                case"-b":
                    System.out.println("是否带括号？（1：带括号；其他：不带括号）");
                    a=in.nextInt();
                    break;
                case "-g":
                    fo.FileC(file2, file3, file4);        //答案和做题文档对比，结果写入Grade文档
                    break;
                case "Do":
                    for(int i=0;i<n;i++)
                    {
                        String s=ex.CreatExp(n,m,a),fstr;   //生成随机表达式并求解
                        String rus=its.suffixToArithmetic(its.infixToSuffix(s));

                        fstr=i+1+":"+s+"\r\n";
                        fo.FileW(file1, fstr);            //表达式写入文档

                        fstr=i+1+":"+rus+"\r\n";
                        fo.FileW(file2, fstr);			  //答案写入文档
                    }
                    break;
                default:
                    System.out.println("无效指令！");
                    break;
            }
            System.out.println("请输入指令：");
        }
    }
}

