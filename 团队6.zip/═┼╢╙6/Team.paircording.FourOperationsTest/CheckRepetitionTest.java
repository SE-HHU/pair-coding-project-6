package Team.paircording.FourOperationsTest;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class CheckRepetitionTest {
    @Test
    public void TestcheckAnswer(){
        List<String> find=new ArrayList<String>();
        Assert.assertEquals(1,2);
        Assert.assertEquals(2,2);
        Assert.assertEquals(3,2);
    }
}
