package Team.paircording.FourOperationsTest;

import Team.paircording.FourOperations.Create;
import org.junit.Assert;
import org.junit.Test;

public class CreateTest {
    @Test
  public void testCreatExp(){
        Create create = new Create();
        Assert.assertEquals(false,create.CreatExp(10,10,1));
    }

    public void testCreateNum(){
        Create create = new Create();
        Assert.assertEquals(1,create.CreatNum(2));
    }

    public void testDating(int a,int b){
        Create create= new Create();
        Assert.assertEquals("2",create.Dating(4,2));
        Assert.assertEquals("",create.Dating(0,0));
        Assert.assertEquals("3/2",create.Dating(3,2));
        Assert.assertEquals("1",create.Dating(1,1));
    }
}

